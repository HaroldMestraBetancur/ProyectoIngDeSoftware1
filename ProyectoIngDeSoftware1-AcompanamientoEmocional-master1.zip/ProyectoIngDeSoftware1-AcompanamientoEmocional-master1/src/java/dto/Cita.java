/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dto;

import java.util.Date;

/**
 *
 * @author mbarbosa
 */
public class Cita {
    
 
    private String idCita;
    private String idUsuario;
    private String idDoctor; 
    private String idFecha;
    private String horaInicio;
    private String horaFin;
    private String idEstado; 

    public Cita() {
        
    }

    public Cita(String idCita, String idUsuario, String idDoctor, String idFecha, String horaInicio, String horaFin, String idEstado) {
        this.idCita = idCita;
        this.idUsuario = idUsuario;
        this.idDoctor = idDoctor;
        this.idFecha = idFecha;
        this.horaInicio = horaInicio;
        this.horaFin = horaFin;
        this.idEstado = idEstado;
    }

    
    public String getIdCita() {
        return idCita;
    }

    public void setIdCita(String idCita) {
        this.idCita = idCita;
    }

    public String getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(String idUsuario) {
        this.idUsuario = idUsuario;
    }

    public String getIdDoctor() {
        return idDoctor;
    }

    public void setIdDoctor(String idDoctor) {
        this.idDoctor = idDoctor;
    }

    public String getIdFecha() {
        return idFecha;
    }

    public void setIdFecha(String idFecha) {
        this.idFecha = idFecha;
    }

    public String getHoraInicio() {
        return horaInicio;
    }

    public void setHoraInicio(String horaInicio) {
        this.horaInicio = horaInicio;
    }

    public String getHoraFin() {
        return horaFin;
    }

    public void setHoraFin(String horaFin) {
        this.horaFin = horaFin;
    }

    public String getIdEstado() {
        return idEstado;
    }

    public void setIdEstado(String idEstado) {
        this.idEstado = idEstado;
    }
    
   
    

  

  
    
}
