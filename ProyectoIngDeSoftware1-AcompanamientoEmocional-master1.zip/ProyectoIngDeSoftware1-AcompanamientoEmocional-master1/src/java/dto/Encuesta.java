/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dto;

/**
 *
 * @author Harold M
 */
public class Encuesta {

    private String NombreUsuario;
    private String SentimientosAng;
    private String DificultadAprender;
    private String AnsiedadJefe;
    private String AnsiedadCompañeros;

    public Encuesta() {
    }

    public Encuesta(String nombre, String SentimientosAng, String DificultadAprender, String AnsiedadJefe, String AnsiedadCompañeros) {
        this.NombreUsuario = nombre;
        this.SentimientosAng = SentimientosAng;
        this.DificultadAprender = DificultadAprender;
        this.AnsiedadJefe = AnsiedadJefe;
        this.AnsiedadCompañeros = AnsiedadCompañeros;
    }

 
    
public String getNombreUsuario() {
        return NombreUsuario;
    }

    public void setNombreUsuario(String NombreUsuario) {
        this.NombreUsuario = NombreUsuario;
    }
    public String getSentimientosAng() {
        return SentimientosAng;
    }

    public void setSentimientosAng(String SentimientosAng) {
        this.SentimientosAng = SentimientosAng;
    }

    public String getDificultadAprender() {
        return DificultadAprender;
    }

    public void setDificultadAprender(String DificultadAprender) {
        this.DificultadAprender = DificultadAprender;
    }

    public String getAnsiedadJefe() {
        return AnsiedadJefe;
    }

    public void setAnsiedadJefe(String AnsiedadJefe) {
        this.AnsiedadJefe = AnsiedadJefe;
    }

    public String getAnsiedadCompañeros() {
        return AnsiedadCompañeros;
    }

    public void setAnsiedadCompañeros(String AnsiedadCompañeros) {
        this.AnsiedadCompañeros = AnsiedadCompañeros;
    }
    
    
    
    
    
}
