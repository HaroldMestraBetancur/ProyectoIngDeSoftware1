/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dto;

/**
 *
 * @author Harold M
 */
public class Bitacora {
    
     private String nombreUsuario;
     private String resumenConversacion;
     private String informacionRelevante;

     
    public Bitacora() {
    }

    public Bitacora(String nombreUsuario, String resumenConversacion, String informacionRelevante) {
        this.nombreUsuario = nombreUsuario;
        this.resumenConversacion = resumenConversacion;
        this.informacionRelevante = informacionRelevante;
    }
     
     

    public String getNombreUsuario() {
        return nombreUsuario;
    }

    public void setNombreUsuario(String nombreUsuario) {
        this.nombreUsuario = nombreUsuario;
    }

    public String getResumenConversacion() {
        return resumenConversacion;
    }

    public void setResumenConversacion(String resumenConversacion) {
        this.resumenConversacion = resumenConversacion;
    }

    public String getInformacionRelevante() {
        return informacionRelevante;
    }

    public void setInformacionRelevante(String informacionRelevante) {
        this.informacionRelevante = informacionRelevante;
    }
     
}
