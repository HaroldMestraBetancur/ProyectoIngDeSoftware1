/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dto;

/**
 *
 * @author Harold M
 */
public class Login {


   
    private String usuario;
    private String contraseña;
    private String idCuenta;
    private String identificacion;
    private String estado;
    private String estadoDoctor;
    private String Sexo;
    private String idRol;
    private String nombre;   
    private String apellidos;   

    public Login() {
    }

    public Login(String usuario, String contraseña, String idCuenta, String identificacion, String estado, String estadoDoctor, String Sexo, String idRol, String nombre, String apellidos) {
        this.usuario = usuario;
        this.contraseña = contraseña;
        this.idCuenta = idCuenta;
        this.identificacion = identificacion;
        this.estado = estado;
        this.estadoDoctor = estadoDoctor;
        this.Sexo = Sexo;
        this.idRol = idRol;
        this.nombre = nombre;
        this.apellidos = apellidos;
    }

    

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getContraseña() {
        return contraseña;
    }

    public void setContraseña(String contraseña) {
        this.contraseña = contraseña;
    }

    public String getIdCuenta() {
        return idCuenta;
    }

    public void setIdCuenta(String idCuenta) {
        this.idCuenta = idCuenta;
    }

    public String getIdentificacion() {
        return identificacion;
    }

    public void setIdentificacion(String identificacion) {
        this.identificacion = identificacion;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getEstadoDoctor() {
        return estadoDoctor;
    }

    public void setEstadoDoctor(String estadoDoctor) {
        this.estadoDoctor = estadoDoctor;
    }

    public String getSexo() {
        return Sexo;
    }

    public void setSexo(String Sexo) {
        this.Sexo = Sexo;
    }

    public String getIdRol() {
        return idRol;
    }

    public void setIdRol(String idRol) {
        this.idRol = idRol;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }
  
  

}
