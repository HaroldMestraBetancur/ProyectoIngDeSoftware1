/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import dto.Doctor;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Harold M
 */
public class OperacionesAdmin {
    
    public int insertar(Doctor dato){
        AdmConexion c = new AdmConexion();
        Connection con = c.getConnection();
        if (con!= null){
            PreparedStatement ps;
            try {
                ps = con.prepareStatement("INSERT INTO Cuenta(nombres, apellidos, identificacion,usuario,contraseña,idrol,estado )VALUES (?, ?, ? , ? , ? , ? , ?)");
            ps.setString(1, dato.getNombres());
             ps.setString(2, dato.getApellidos());
              ps.setString(3, dato.getIdentificacion());
            ps.setString(4, dato.getUsername());
            ps.setString(5, dato.getPassword());
            ps.setString(6, dato.getRol());
            ps.setString(7, dato.getEstado());
            
            return ps.executeUpdate();
            } catch (SQLException ex) {
                Logger.getLogger(OperacionesUsuario.class.getName()).log(Level.SEVERE, "Error al insertar el Doctor", ex);
            }finally{
                c.cerrarConnexion(con);
            }
        }
        return 0;
       
    }
    
    public Doctor consultar(Doctor doctor){
        AdmConexion c = new AdmConexion();
        Connection con = c.getConnection();
        
        try {
            PreparedStatement ps=con.prepareStatement("SELECT Username, Sexo FROM usuario where username = ?");
            ps.setString(1, doctor.getUsername());
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                 doctor.setUsername(rs.getString(1));
                 doctor.setApellidos(rs.getString(2));
            }
        } catch (SQLException ex) {
            Logger.getLogger(OperacionesUsuario.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            c.cerrarConnexion(con);
        }
        return doctor;
    }
}
