/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import dto.Usuario;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author mbarbosa
 */
public class OperacionesUsuario {
    
    public int insertar(Usuario dato){
        AdmConexion c = new AdmConexion();
        Connection con = c.getConnection();
        if (con!= null){
            PreparedStatement ps;
            try {
                ps = con.prepareStatement("INSERT INTO Cuenta(Usuario, Contraseña, Sexo , idRol,estado )VALUES (?, ?, ? , ? , ?)");
            ps.setString(1, dato.getUsuario());
            ps.setString(2, dato.getContraseña());
            ps.setString(3, dato.getSexo());
            ps.setString(4, "1");
            ps.setString(5, "A");
            
            return ps.executeUpdate();
            } catch (SQLException ex) {
                Logger.getLogger(OperacionesUsuario.class.getName()).log(Level.SEVERE, "Error al insertar al registrarse", ex);
            }finally{
                c.cerrarConnexion(con);
            }
        }
        return 0;
        
    }
    
    public Usuario consultar(Usuario usuario){
        AdmConexion c = new AdmConexion();
        Connection con = c.getConnection();
        
        try {
            PreparedStatement ps=con.prepareStatement("SELECT Username, Sexo FROM usuario where username = ?");
            ps.setString(1, usuario.getUsuario());
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                 usuario.setUsuario(rs.getString(1));
                 usuario.setSexo(rs.getString(2));
            }
        } catch (SQLException ex) {
            Logger.getLogger(OperacionesUsuario.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            c.cerrarConnexion(con);
        }
        return usuario;
    }
    
}
