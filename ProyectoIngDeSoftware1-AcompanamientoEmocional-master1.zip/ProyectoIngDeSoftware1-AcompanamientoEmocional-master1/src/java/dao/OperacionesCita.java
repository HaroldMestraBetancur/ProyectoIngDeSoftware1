/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import dto.Cita;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author mbarbosa
 */
public class OperacionesCita {
    
    public int insertar(Cita dato){
        AdmConexion c = new AdmConexion();
        Connection con = c.getConnection();
        if (con!= null){
            PreparedStatement ps;
            try {
                ps = con.prepareStatement("INSERT INTO Cita(Hora_Inicio_idHora, Fecha_IdFecha, Doctor_IdDoctor ,Hora_Fin_idHora ,EstadoCita_idEstadoCita, Usuario_IdUsuario , idEstado )VALUES (?, ?, ? , ? , ? , ?,?)");
           ps.setString(1, dato.getHoraInicio());
           ps.setString(2, dato.getIdFecha());
           ps.setString(3, dato.getIdDoctor());
           ps.setString(4, dato.getHoraFin());
           ps.setString(5, "1");
           ps.setString(6, "2");
           ps.setString(7, "A");
           
           
                System.out.println("prueba ");
            
            return ps.executeUpdate();
            } catch (SQLException ex) {
                Logger.getLogger(OperacionesUsuario.class.getName()).log(Level.SEVERE, "Error al insertar la cita", ex);
            }finally{
                c.cerrarConnexion(con);
            }
        }
        return 0;
        
    }
    
    public Cita consultar(Cita usuario){
        AdmConexion c = new AdmConexion();
        Connection con = c.getConnection();
        
        try {
            PreparedStatement ps=con.prepareStatement("SELECT Username, Sexo FROM usuario where username = ?");
            //ps.setString(1, usuario.getUsername());
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
            //     usuario.setUsername(rs.getString(1));
            //     usuario.setSexo(rs.getString(2));
            }
        } catch (SQLException ex) {
            Logger.getLogger(OperacionesUsuario.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            c.cerrarConnexion(con);
        }
        return usuario;
    }
}
