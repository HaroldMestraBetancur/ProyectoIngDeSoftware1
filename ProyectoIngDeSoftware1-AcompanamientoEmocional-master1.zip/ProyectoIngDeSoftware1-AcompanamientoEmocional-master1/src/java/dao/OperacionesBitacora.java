/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import dto.Bitacora;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Harold M
 */
public class OperacionesBitacora {
   
     public int insertar(Bitacora dato){
        AdmConexion c = new AdmConexion();
        Connection con = c.getConnection();
        if (con!= null){
            PreparedStatement ps;
            try {
                ps = con.prepareStatement("INSERT INTO BitacoraCita( NombreUsuario, ResumenConversacion, InformacionRelevanteEncuesta , Estado)VALUES (?, ?, ? , ? )");
            ps.setString(1, dato.getNombreUsuario());
            ps.setString(2, dato.getResumenConversacion());
            ps.setString(3, dato.getInformacionRelevante());
            ps.setString(4, "A");
            
            return ps.executeUpdate();
            } catch (SQLException ex) {
                Logger.getLogger(OperacionesUsuario.class.getName()).log(Level.SEVERE, "Error al intentar agregar esta biracora", ex);
            }finally{
                c.cerrarConnexion(con);
            }
        }
        return 0;
        
    }
}
