/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import dto.Cita;
import dto.Login;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Harold M
 */
public class OperacionesLogin {
    
      public Login verificacionUsuario(String usuario,String contrasena){
          AdmConexion c = new AdmConexion();
        Connection con = c.getConnection();
       PreparedStatement ps;
       Login lg = new Login();
       
        if (con!= null){
            try {
         
            // Ejecuta estos datos a la base de datos, lenguaje sql
            ps= con.prepareStatement("select idCuenta,idRol from Cuenta Where Usuario=? and Contraseña=? and Estado=? ");
            ps.setString(1, usuario);
            ps.setString(2, contrasena);
            ps.setString(3, "A");
            
            //Regresando todos los usuarios y contraseñas de la base de datios
           
            ResultSet rs=ps.executeQuery();
            
           while (rs.next()) {
              lg.setIdRol(rs.getString(2));
              lg.setIdCuenta(rs.getInt(1));
            }
            
            //Crea 
            
            return lg;
            
            } catch (SQLException ex) {
                Logger.getLogger(OperacionesUsuario.class.getName()).log(Level.SEVERE, "Error al insertar el paciente", ex);
            }finally{
                c.cerrarConnexion(con);
            }
        }
        
        return lg;
        
    }
}
