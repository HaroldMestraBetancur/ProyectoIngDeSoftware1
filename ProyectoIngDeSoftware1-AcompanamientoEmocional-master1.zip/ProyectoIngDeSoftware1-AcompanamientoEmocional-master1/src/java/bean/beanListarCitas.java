/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bean;

import dao.OperacionesCita;
import dto.Cita;
import dto.Doctor;
import dto.Usuario;
import java.io.Serializable;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

/**
 *
 * @author mbarbosa
 */
@ManagedBean
@ViewScoped
public class beanListarCitas implements Serializable{
    
    private List<Cita> citas;
    
    private OperacionesCita oper;
    
    public beanListarCitas() {
      oper = new OperacionesCita();
   }
    
    @PostConstruct
    public void init() {
        citas = cargarPro();
    }
    
    public String regresar(){
       return "Propietario";
    }
    
    public List<Cita> getCita(){
      return citas;
   }

   public void setCita(List<Cita> propieatarios) {
      this.citas = propieatarios;
   }

   private List<Cita> cargarPro() {

      //return oper.consultaT();
       return null;
      
   }

}