/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bean;

import dao.OperacionesBitacora;
import dto.Bitacora;
import java.io.Serializable;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;



@ManagedBean
@ViewScoped
public class beanBitacora implements Serializable{

    

     private String nombreUsuario;
     private String resumenConversacion;
     private String informacionRelevante;

    public beanBitacora() {
    }
    
     
     public void insertar (){
        if (nombreUsuario == null || nombreUsuario.isEmpty() || resumenConversacion == null || resumenConversacion.isEmpty() || informacionRelevante == null || informacionRelevante.isEmpty()){
            System.out.println("- -- - - null");
            return ;
        }
        Bitacora b = new Bitacora();
        b.setNombreUsuario(nombreUsuario);
        b.setResumenConversacion(resumenConversacion);
        b.setInformacionRelevante(informacionRelevante);
        
        OperacionesBitacora oper = new OperacionesBitacora();
        int rta = oper.insertar(b);
        System.out.println("rta "+rta);
    }
     
public String getNombreUsuario() {
        return nombreUsuario;
    }

    public void setNombreUsuario(String nombreUsuario) {
        this.nombreUsuario = nombreUsuario;
    }

    public String getResumenConversacion() {
        return resumenConversacion;
    }

    public void setResumenConversacion(String resumenConversacion) {
        this.resumenConversacion = resumenConversacion;
    }

    public String getInformacionRelevante() {
        return informacionRelevante;
    }

    public void setInformacionRelevante(String informacionRelevante) {
        this.informacionRelevante = informacionRelevante;
    }
    
     
}