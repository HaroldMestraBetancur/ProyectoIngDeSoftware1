/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bean;


import dao.OperacionesAdmin;
import dao.OperacionesUsuario;
import dto.Doctor;
import java.io.Serializable;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

/**
 *
 * @author mbarbosa
 */
@ManagedBean
@ViewScoped
public class beanInsertarPsicologoAdmin implements Serializable{

   
   
    private String nombres;
    private String apellidos;
    private String identificacion;
    private String usuario; 
    private String contraseña;
    private String idrol;
    
    public beanInsertarPsicologoAdmin() {
    }
    
     public void insertar (){
        if (nombres == null || nombres.isEmpty() || apellidos == null || apellidos.isEmpty() || identificacion == null || identificacion.isEmpty() ||
                usuario == null || usuario.isEmpty()|| contraseña == null || contraseña.isEmpty()|| idrol == null || idrol.isEmpty() ){
            
            
            System.out.println("- -- - - null");
            return ;
        }
        Doctor d = new Doctor();
        d.setNombres(nombres);
        d.setApellidos(apellidos);
        d.setIdentificacion(identificacion);
        d.setUsername(usuario);
        d.setPassword(contraseña);
        d.setRol(idrol);
        d.setEstado("A");
        OperacionesAdmin oper = new OperacionesAdmin();
        int rta = oper.insertar(d);
        System.out.println("rta "+rta);
    }

      public String getNombres() {
        return nombres;
    }

    public void setNombres(String nombres) {
        this.nombres = nombres;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public String getIdentificacion() {
        return identificacion;
    }

    public void setIdentificacion(String identificacion) {
        this.identificacion = identificacion;
    }

    public String getUsername() {
        return usuario;
    }

    public void setUsername(String username) {
        this.usuario = username;
    }

    public String getPassword() {
        return contraseña;
    }

    public void setPassword(String password) {
        this.contraseña = password;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getContraseña() {
        return contraseña;
    }

    public void setContraseña(String contraseña) {
        this.contraseña = contraseña;
    }

    public String getIdrol() {
        return idrol;
    }

    public void setIdrol(String idrol) {
        this.idrol = idrol;
    }
  

    public String salir(){
       return "MenuAdmin";
    }
    
}
