/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bean;


import dao.OperacionesLogin;
import dao.OperacionesUsuario;
import dto.Login;
import dto.Usuario;
import java.io.IOException;
import java.io.Serializable;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;

/**
 *
 * @author mbarbosa
 */
@ManagedBean
@ViewScoped
public class beanLogin implements Serializable{

    private String usuario;
    private String contraseña;
    
    
      public void verificacion() throws IOException{
          // Para mostrar mensage 
         FacesContext context=FacesContext.getCurrentInstance();
          //llama al dao que tiene el metodo que trae de la base de datos
        OperacionesLogin ol= new OperacionesLogin();
        Login login=ol.verificacionUsuario(usuario, contraseña);
        if(login.getIdRol()!=null){
            // intento de acceder sesion y me manda mensaje de bienvenida
        context.addMessage(null,new FacesMessage(FacesMessage.SEVERITY_INFO,"Exito","Bienvenido"));
        //depende del rol lo redirecciona a la pagina
        
     if(login.getIdRol().equals("1")){
         beanPaciente bp= new beanPaciente()  ;
         bp.setIdPacienteG(login.getIdCuenta());
         
           FacesContext.getCurrentInstance().getExternalContext()
                .redirect("Paciente/MenuUsuario.xhtml");
       
    }
    else if(login.getIdRol().equals("2")){
        beanPsicologo bp= new beanPsicologo()  ;
         bp.setIdPsicologoG(login.getIdCuenta());
         
          FacesContext.getCurrentInstance().getExternalContext()
                .redirect("Psicologo/MenuPsicologo.xhtml");
    }
    else if(login.getIdRol().equals("3")){
        
          FacesContext.getCurrentInstance().getExternalContext()
                .redirect("Administrador/MenuAdmin.xhtml");
          }
      }
        context.addMessage(null,new FacesMessage(FacesMessage.SEVERITY_ERROR,"Error","El usuario o la clave estan mal"));
            
        }
   
    
   
    
    public void autenticacion(){
       
    }
    
    
    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getContraseña() {
        return contraseña;
    }

    public void setContraseña(String contraseña) {
        this.contraseña = contraseña;
    }
    
    
}
