/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bean;

import dao.OperacionesCita;
import dto.Cita;
import java.io.Serializable;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

/**
 *
 * @author Harold M
 */

@ManagedBean
@ViewScoped
public class beanCrearCita implements Serializable{

     private String horaInicio;
     private String horaFin;
     private String idDoctor;
     private String idFecha;

    public beanCrearCita() {
    }

     public void insertar (){
        if (horaInicio == null || horaInicio.isEmpty()|| idFecha == null || idFecha.isEmpty()|| idDoctor == null || idDoctor.isEmpty()|| horaFin == null || horaFin.isEmpty()){
            System.out.println("- -- - - null");
            return ;
        }
        Cita c = new Cita();
        c.setHoraInicio(horaInicio);
        c.setIdFecha(idFecha);
        c.setIdDoctor(idDoctor);
        c.setHoraFin(horaFin);
       
        
        OperacionesCita oper = new OperacionesCita();
        int rta = oper.insertar(c);
        System.out.println("rta "+rta);
    }
     
     
    public String getHoraInicio() {
        return horaInicio;
    }

    public void setHoraInicio(String horaInicio) {
        this.horaInicio = horaInicio;
    }

    public String getHoraFin() {
        return horaFin;
    }

    public void setHoraFin(String horaFin) {
        this.horaFin = horaFin;
    }

    public String getIdDoctor() {
        return idDoctor;
    }

    public void setIdDoctor(String idDoctor) {
        this.idDoctor = idDoctor;
    }
    public String getIdFecha() {
        return idFecha;
    }

    public void setIdFecha(String idFecha) {
        this.idFecha = idFecha;
    }
    
}
