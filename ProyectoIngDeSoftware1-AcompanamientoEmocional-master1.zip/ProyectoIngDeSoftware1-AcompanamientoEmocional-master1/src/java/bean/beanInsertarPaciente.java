/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bean;

import dao.OperacionesUsuario;
import dto.Usuario;
import java.io.Serializable;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

/**
 *
 * @author mbarbosa
 */
@ManagedBean
@ViewScoped
public class beanInsertarPaciente implements Serializable{
    
    private String usuario; 
    private String contraseña;
    private String sexo; 

    public beanInsertarPaciente() {
    }
    
     public void insertar (){
        if (usuario == null || usuario.isEmpty() || contraseña == null || contraseña.isEmpty() || sexo == null || sexo.isEmpty()){
            System.out.println("- -- - - null");
            return ;
        }
        Usuario u = new Usuario();
        u.setUsuario(usuario);
        u.setContraseña(contraseña);
        u.setSexo(sexo);
        
        OperacionesUsuario oper = new OperacionesUsuario();
        int rta = oper.insertar(u);
        System.out.println("rta "+rta);
    }
     
    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getContraseña() {
        return contraseña;
    }

    public void setContraseña(String contraseña) {
        this.contraseña = contraseña;
    }

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }
   
    
    public String salir(){
       return "index";
    }
    
}
