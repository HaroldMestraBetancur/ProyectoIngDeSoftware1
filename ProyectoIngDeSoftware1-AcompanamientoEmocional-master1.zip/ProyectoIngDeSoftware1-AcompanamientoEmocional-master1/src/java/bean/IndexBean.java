/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bean;

import java.io.Serializable;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

/**
 *
 * @author mbarbosa
 */
@ManagedBean
@ViewScoped
public class IndexBean implements Serializable{
    
    public String InsertarUsuario(){
      //System.out.println("Ingreso ..");
      return "Usuario";
   }
    public String InsertarDoctor(){
      //System.out.println("Ingreso ..");
      return "RegistroUsuarioAdmin";
   }
    
   public String ConsultarDisponibilidad(){
      //System.out.println("Ingreso ..");
      return "CitasDisponibles";
   }
   
   public String PrepararCita(){
      //System.out.println("Ingreso ..");
      return "PrepararCita";
   }
   
     public String RevisaEncuesta(){
      //System.out.println("Ingreso ..");
      return "EncuestaRevisar";
   }
      public String ConsultarHistoriaClinica(){
      //System.out.println("Ingreso ..");
      return "HistoriaClinica";
   }
       public String ConversacionCita(){
      //System.out.println("Ingreso ..");
      return "ConversacionPsicologo";
   }
        public String BitacoraConsulta(){
      //System.out.println("Ingreso ..");
      return "Bitacora";
   }
        public String VolverMenuPsicologo(){
      //System.out.println("Ingreso ..");
      return "MenuPsicologo";
   }
        
    
}
