/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bean;

import java.io.IOException;
import java.io.Serializable;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;

/**
 *
 * @author mbarbosa
 */
@ManagedBean
@ViewScoped
public class IndexBean implements Serializable{
    
    public String InsertarUsuario(){
      //System.out.println("Ingreso ..");
      return "Paciente/RegistroUsuario";
   }
    public String InsertarDoctor(){
      //System.out.println("Ingreso ..");
      return "RegistroUsuarioAdmin";
   }
   
   public String PrepararCita(){
      //System.out.println("Ingreso ..");
      return "PrepararCita";
   }
   
     public String RevisaEncuesta(){
      //System.out.println("Ingreso ..");
      return "EncuestaRevisar";
   }
      public String ConsultarHistoriaClinica(){
      //System.out.println("Ingreso ..");
      return "HistoriaClinica";
   }
       public String ConversacionCita(){
      //System.out.println("Ingreso ..");
      return "ConversacionPsicologo";
   }
        public String BitacoraConsulta(){
      //System.out.println("Ingreso ..");
      return "Bitacora";
   }
        public String VolverMenuPsicologo(){
      //System.out.println("Ingreso ..");
      return "MenuPsicologo";
   }
        public String VolverMenuPaciente(){
      //System.out.println("Ingreso ..");
      return "MenuUsuario";
   }
     public String ConsultarDisponibilidad(){
      //System.out.println("Ingreso ..");
      return "ConsultarDisponibilidad";
   }
     public String VerAgenda(){
      //System.out.println("Ingreso ..");
      return "VerAgenda";
   }
     public String  Encuesta(){
      //System.out.println("Ingreso ..");
      return "Encuesta";
   }
      public String  ConversacionUsuario(){
      //System.out.println("Ingreso ..");
      return "ConversacionUsuario";
   }
      public void Salir() throws IOException{
          ExternalContext ec= FacesContext.getCurrentInstance().getExternalContext();
ec.redirect(ec.getRequestContextPath() + "/faces/index.xhtml");
   }
      public String CrearCitas(){
      //System.out.println("Ingreso ..");
      return "CrearCitas";
   }
   
}
