/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bean;

import dao.OperacionesEncuesta;
import dto.Encuesta;
import java.io.Serializable;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

/**
 *
 * @author Harold M
 */
@ManagedBean
@ViewScoped
public class beanEncuesta implements Serializable{

    private String NombreUsuario;
    private String SentimientosAng;
    private String DificultadAprender;
    private String AnsiedadJefe;
    private String AnsiedadCompañeros;

    public beanEncuesta() {
    }
public void insertar (){
        if (NombreUsuario == null || NombreUsuario.isEmpty() || SentimientosAng == null || SentimientosAng.isEmpty() || DificultadAprender == null 
                || DificultadAprender.isEmpty()|| AnsiedadJefe == null || AnsiedadJefe.isEmpty()|| AnsiedadCompañeros == null || AnsiedadCompañeros.isEmpty()){
            System.out.println("- -- - - null");
            return ;
        }
        Encuesta e = new Encuesta();
        e.setNombreUsuario(NombreUsuario);
        e.setSentimientosAng(SentimientosAng);
        e.setDificultadAprender(DificultadAprender);
        e.setAnsiedadJefe(AnsiedadJefe);
        e.setAnsiedadCompañeros(AnsiedadCompañeros);
        
        
        OperacionesEncuesta oper = new OperacionesEncuesta();
        int rta = oper.insertar(e);
        System.out.println("rta "+rta);
    }
    
    
    public String getNombreUsuario() {
        return NombreUsuario;
    }

    public void setNombreUsuario(String NombreUsuario) {
        this.NombreUsuario = NombreUsuario;
    }

    public String getSentimientosAng() {
        return SentimientosAng;
    }

    public void setSentimientosAng(String SentimientosAng) {
        this.SentimientosAng = SentimientosAng;
    }

    public String getDificultadAprender() {
        return DificultadAprender;
    }

    public void setDificultadAprender(String DificultadAprender) {
        this.DificultadAprender = DificultadAprender;
    }

    public String getAnsiedadJefe() {
        return AnsiedadJefe;
    }

    public void setAnsiedadJefe(String AnsiedadJefe) {
        this.AnsiedadJefe = AnsiedadJefe;
    }

    public String getAnsiedadCompañeros() {
        return AnsiedadCompañeros;
    }

    public void setAnsiedadCompañeros(String AnsiedadCompañeros) {
        this.AnsiedadCompañeros = AnsiedadCompañeros;
    }
    
}
